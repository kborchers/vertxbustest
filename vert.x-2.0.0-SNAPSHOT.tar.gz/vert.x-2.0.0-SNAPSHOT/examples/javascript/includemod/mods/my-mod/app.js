load("vertx.js");
console.log("In app");
