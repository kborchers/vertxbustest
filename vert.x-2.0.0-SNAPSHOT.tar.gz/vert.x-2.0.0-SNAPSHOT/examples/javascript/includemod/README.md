# Test of modules including other modules

Run from this directory with:

vertx runmod my-mod