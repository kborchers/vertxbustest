load('vertx.js')

function vertxStop() {
}