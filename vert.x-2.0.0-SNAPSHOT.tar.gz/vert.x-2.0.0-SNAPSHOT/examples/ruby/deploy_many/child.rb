require "vertx"

#puts "in child"

def vertx_stop
  #puts "in stop"
end